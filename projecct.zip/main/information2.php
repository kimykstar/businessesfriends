<!DOCTYPE html>
<html lang="ko">
  <head>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>유저페이지</title>
    <style>
      h1{
        justify-content: center;
        text-align: center;
        margin-top: 15%;
        margin-bottom: 15%;
      }
      .listname{
        list-style-position: inside;
        list-style: none;
        display: block;
      }
      li{
        margin-bottom: 50px;
      }
      a{
        text-decoration: none;
        color: black;
      }
      a:active{
        color:none;
        text-decoration: none;
      }
    </style>
  </head>
  <body> 
    <?php
      session_start();
      $name = $_SESSION['user_name'];
      $user_id = $_SESSION['user_id'];
      $user_type = $_SESSION['user_type'];

      // 가게 사용자인 경우
      if($user_type != 1){
        $menu1 = '<li><a href="../store_regi/cupon_regist.php" style="font-size:18px">가게 쿠폰 등록하기</a></li>';
        $menu2 = '<li><a href="../store_regi/store_regi.html" style="font-size:18px">가게 등록하기</a></li>';
        $menu3 = '<li><a href="../login/index.html" style="font-size:18px">로그아웃</a></li>';
      }else{
        $menu1 = '<li><a href="my_cupon.php" style="font-size:18px">내가 받은 쿠폰</a></li>';
        $menu2 = '<li><a href="attend_cupon.html" style="font-size:18px">출석체크</a></li>';
        $menu3 = '<li><a href="../login/index.html" style="font-size:18px">로그아웃</a></li>';
      }
    ?>

    <div class="userpage">
      <h1><?="(".$name.")"?></h1>
      <ul class="listname">
        <?=$menu1?>
        <?=$menu2?>
        <?=$menu3?>
      </ul>
    </div>
    
    <script>
      // var user_name = sessionStorage.getItem('user_name');
      
      // $(document).ready(function(){
      //   document.write(user_name);
      //   document.getElementById('user_name').value = user_name;
      // });

      

      // alert(user_name);
    </script>
  </body>
</html>

