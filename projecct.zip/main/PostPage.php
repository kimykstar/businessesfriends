<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width">
  <link href="bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.2.0/css/all.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
  
  <title>가게 게시글 내용</title>

  <style>

    @import url('https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap');

    html{
      font-family: 'Nanum Gothic', sans-serif;
    }

    body {
      justify-content: center;
      background-color: white;
    }

    hr{
      height: 1px;
      border: none;
      background-color: gray;  
    }
    

    .slider{
      width: 500px;
      height: 650px;
      position: relative;
      margin: 0 auto;
      overflow: hidden; /* 현재 슬라이드 오른쪽에 위치한 나머지 슬라이드 들이 보이지 않도록 가림 */
    }

    .slider input[type=radio]{
      display: none;
    }

    ul.imgs{
      padding: 0;
      margin: 0;
      list-style: none;    
    }

    ul.imgs li{
      position: absolute;
      left: 640px;
      transition-delay: 0.5s; /* 새 슬라이드가 이동해 오는 동안 이전 슬라이드 이미지가 배경이 보이도록 지연 */

      padding: 0;
      margin: 0;
    }

    .post_comment_btn{
      background-color:rgba(0,0,0,0);
      /* background-color:black;  */
      color:rgb(31, 177, 221); 
      border:none; 
      /* padding-left: 13em; */
      float: right;
      margin-right: 20px;
    }

    #post_comment_input{
      border:none;
      outline: 0;
    }


    .bullets{
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      bottom: 20px;
      z-index: 2;
    }

    .bullets label{
      display: inline-block;
      border-radius: 50%;
      background-color: rgba(0,0,0,0.55);
      width: 15px;
      height: 15px;
      cursor: pointer;
    }

    /* 현재 선택된 불릿 배경 흰색으로 구분 표시 */
    .slider input[type=radio]:nth-child(1):checked~.bullets>label:nth-child(1){
      background-color: #fff;
    }
    .slider input[type=radio]:nth-child(2):checked~.bullets>label:nth-child(2){
      background-color: #fff;
    }
    .slider input[type=radio]:nth-child(3):checked~.bullets>label:nth-child(3){
      background-color: #fff;
    }
    .slider input[type=radio]:nth-child(4):checked~.bullets>label:nth-child(4){
      background-color: #fff;
    }
    
    .slider input[type=radio]:nth-child(1):checked~ul.imgs>li:nth-child(1){
      left: 0;
      transition: 0.5s;
      z-index:1;
    }
    .slider input[type=radio]:nth-child(2):checked~ul.imgs>li:nth-child(2){
      left: 0;
      transition: 0.5s;
      z-index:1;
    }
    .slider input[type=radio]:nth-child(3):checked~ul.imgs>li:nth-child(3){
      left: 0;
      transition: 0.5s;
      z-index:1;
    }
    .slider input[type=radio]:nth-child(4):checked~ul.imgs>li:nth-child(4){
      left: 0;
      transition: 0.5s;
      z-index:1;
    }

    .footer{
      margin-top: 40px;
      margin-bottom: 40px;
      margin-left: 180px;
    }

    .footer a{
      margin-left: 10px;
      margin-right: 10px;
      text-decoration:none;
    }

  </style>
 
</head>
<body>

  <!-- 헤더 -->
  <header class="py-3 mb-3 border-bottom">
    <div class="container-fluid d-grid gap-3 align-items-center" style="grid-template-columns: 1fr 2fr;">
      <div style="padding-top: 12px">
        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
          <svg xmlns="http://www.w3.org/2000/svg" style="margin-right:8px" width="23" height="23" fill="currentColor" class="bi bi-shop" viewBox="0 0 16 16">
              <path d="M2.97 1.35A1 1 0 0 1 3.73 1h8.54a1 1 0 0 1 .76.35l2.609 3.044A1.5 1.5 0 0 1 16 5.37v.255a2.375 2.375 0 0 1-4.25 1.458A2.371 2.371 0 0 1 9.875 8 2.37 2.37 0 0 1 8 7.083 2.37 2.37 0 0 1 6.125 8a2.37 2.37 0 0 1-1.875-.917A2.375 2.375 0 0 1 0 5.625V5.37a1.5 1.5 0 0 1 .361-.976l2.61-3.045zm1.78 4.275a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 1 0 2.75 0V5.37a.5.5 0 0 0-.12-.325L12.27 2H3.73L1.12 5.045A.5.5 0 0 0 1 5.37v.255a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0zM1.5 8.5A.5.5 0 0 1 2 9v6h1v-5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v5h6V9a.5.5 0 0 1 1 0v6h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1V9a.5.5 0 0 1 .5-.5zM4 15h3v-5H4v5zm5-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3zm3 0h-2v3h2v-3z"/>
            </svg>
          <span style="font-size: 15px;">Simple header</span>
        </a>
      </div>

      <div class="d-flex align-items-center">
        <form class="w-100 me-3" role="search">
          <input type="search" class="form-control" placeholder="Search..." aria-label="Search">
        </form>

        <div class="flex-shrink-0 dropdown">
          <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="img/IU.jpg" alt="mdo" width="32" height="32" class="rounded-circle">
          </a>
          <ul class="dropdown-menu text-small shadow">
            <li><a class="dropdown-item" href="#">New project...</a></li>
            <li><a class="dropdown-item" href="#">Settings</a></li>
            <li><a class="dropdown-item" href="#">Profile</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Sign out</a></li>
          </ul>
        </div>
      </div>
    </div>
  </header>
  

  <script src="bootstrap.bundle.min.js">
  </script>

  <script>

    function SNS(Profile_photo, Profile_id, Profile_date, img, con, ii){

      //계정 사진
      let pp = document.createElement('img');
      pp.className = 'rounded-circle';
      pp.src = Profile_photo;
      pp.height = "32";
      pp.style.marginBottom = '10px';
      pp.style.marginLeft = '5px';
      document.body.appendChild(pp);

      //계정 이름
      let pi = document.createElement('span');
      let nametext = document.createTextNode(Profile_id);
      pi.style.fontWeight = 'bold';
      pi.style.marginBottom = '10px';
      pi.style.marginLeft = '5px';
      pi.style.color='gray';
      pi.appendChild(nametext);
      document.body.appendChild(pi);

      //계정 날짜
      let pd = document.createElement('span');
      let datetext = document.createTextNode(Profile_date);
      pd.appendChild(datetext);
      pd.style.marginBottom = '10px';
      pd.style.marginLeft = '5px';
      pd.style.color='gray';
      document.body.appendChild(pd);

      //사진 올리는 곳
      let image = document.createElement('img');
      image.src = img;
      image.style.width = "100vw";
      document.body.appendChild(image);

      //하트랑 댓글 이미지
      let heart = document.createElement('img');
      heart.src = '/store_board/data/emptyheart.png';
      heart.height = "20";
      heart.style.marginLeft = '10px';
      document.body.appendChild(heart);
      let comment = document.createElement('img');
      comment.src = '/store_board/data/comment.png';
      comment.height = "20";
      comment.style.marginLeft = '10px';
      document.body.appendChild(comment);

      //내용
      let div = document.createElement('div');
      let text = document.createTextNode(con);
      div.style.paddingLeft = '10px';
      div.style.paddingTop = '30px';
      div.appendChild(text);
      document.body.appendChild(div);

      //계정 댓글 보이는 곳
      let a = document.createElement('div');
      a.classList.add('comment_list');
      document.body.appendChild(a);

      document.write("<hr>");

      //댓글 다는 곳
      let p = document.createElement('img');
      p.classList ='rounded-circle';
      p.src = ii;
      p.height = "30";
      p.style.marginBottom = '10px';
      p.style.marginLeft = '5px';
      document.body.appendChild(p);

      let inpu = document.createElement('input');
      inpu.setAttribute("placeholder", "댓글 달기...");
      inpu.id = 'post_comment_input';
      document.body.appendChild(inpu);
      
      let bu = document.createElement('button');
      bu.classList.add('post_comment_btn');
      bu.innerText = "게시";
      document.body.appendChild(bu);

      document.write("<hr>");
    }    

    const postCommentInFeed = () => {
      const commentInput = document.getElementById('post_comment_input');
      //const commentInput = document.getElementsByClassName('post_comment_input');
      const commentPostBtn = document.getElementsByClassName('post_comment_btn')[0];

      // 댓글 입력시 요소 생성
      const addNewComment = () => {

        const newCommentLocation = document.getElementsByClassName('comment_list')[0];
        const newComment = document.createElement('li');

        newComment.innerHTML = `
        <div class="user_desc">
          <em>iAmUser</em>
          <span>${commentInput.value}</span>
        </div>
        ` 
        ;

        newCommentLocation.appendChild(newComment);
        commentInput.value = '';
      }


      // 사용자 입력 들어올 시, 게시 버튼 활성화
      commentInput.addEventListener('keyup', () => {
        commentInput.value ? commentPostBtn.style.opacity = '1' : commentPostBtn.style.opacity = '.3';
        if (window.event.keyCode === 13 && commentInput.value) {
          addNewComment();
        }
      });

      // 댓글 게시
      commentPostBtn.addEventListener('click', () => {
        if (commentInput.value) {
          addNewComment();
        } else {
          alert('댓글이 입력되지 않았습니다 😳');
        }
      })
    }

    
    SNS('img/bread logo.jpg', '이름', 'ㆍ2022', 'img/IU.jpg','내용어쩌구', 'img/IU.jpg');
    postCommentInFeed();
    
  </script>

  <!-- 아래 -->
  <div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
      <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
        <svg xmlns="http://www.w3.org/2000/svg" style="margin-right:8px" width="23" height="23" fill="currentColor" class="bi bi-shop" viewBox="0 0 16 16">
          <path d="M2.97 1.35A1 1 0 0 1 3.73 1h8.54a1 1 0 0 1 .76.35l2.609 3.044A1.5 1.5 0 0 1 16 5.37v.255a2.375 2.375 0 0 1-4.25 1.458A2.371 2.371 0 0 1 9.875 8 2.37 2.37 0 0 1 8 7.083 2.37 2.37 0 0 1 6.125 8a2.37 2.37 0 0 1-1.875-.917A2.375 2.375 0 0 1 0 5.625V5.37a1.5 1.5 0 0 1 .361-.976l2.61-3.045zm1.78 4.275a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 1 0 2.75 0V5.37a.5.5 0 0 0-.12-.325L12.27 2H3.73L1.12 5.045A.5.5 0 0 0 1 5.37v.255a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0zM1.5 8.5A.5.5 0 0 1 2 9v6h1v-5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v5h6V9a.5.5 0 0 1 1 0v6h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1V9a.5.5 0 0 1 .5-.5zM4 15h3v-5H4v5zm5-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3zm3 0h-2v3h2v-3z"/>
        </svg>
        <span class="fs-4" style="padding: 8px;">Simple header</span>
      </a>
      <ul class="nav nav-pills">
        <li class="nav-item"><a href="home.php" class="bi bi-house-door fa-2x" style="color: gray; padding: 8px 16px;" ></a></li>
        <li class="nav-item"><a href="store_list.php" class="bi bi-shop-window fa-2x" style="color: gray; padding: 8px 16px;"></a></li>
        <li class="nav-item"><a href="#" class="bi bi-card-checklist fa-2x" style="color: gray; padding: 8px 16px;"></a></li>
        <li class="nav-item"><a href="information.php" class="bi bi-person-badge-fill fa-2x" style="color: gray; padding: 8px 16px;"></></a></li>
      </ul>
    </header>
  </div>

  <div class="footer">
    <a href="http://faceboo.com">
      <img src="https://bakey-api.codeit.kr/files/629/images/facebook.png" height="20">
    </a>
    <a href="http://faceboo.com">
      <img src="https://bakey-api.codeit.kr/files/629/images/instagram.png" height="20">
    </a>
    <a href="http://faceboo.com">
      <img src="https://bakey-api.codeit.kr/files/629/images/twitter.png" height="20">
    </a>
  </div>

</body>
</html>