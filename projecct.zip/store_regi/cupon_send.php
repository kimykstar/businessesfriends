<?php
    include "dbconnect.php";
    // $conn = mysqli_connect('localhost', 'root', '', 'project');
    $phone_number = $_POST['tel'];
    $select_sql = "SELECT user_id FROM user WHERE user_phone='$phone_number'";

    $select_result = $mysqli_query($conn, $select_sql);
    // 번호에 해당하는 사용자가 있는 경우
    if($select_result){
        $insert_sql = 'INSERT INTO '
    }else{
        echo "<script>alert('없는 사용자입니다.'); location.replace('cupon_regi.php');</script>"
    }

?>