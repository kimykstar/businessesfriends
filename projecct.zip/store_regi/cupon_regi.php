<!DOCTYPE html>
<html lang="ko">
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width">
  <title>내 가게 쿠폰 입력</title>
  <style>
    body {
    margin: 50px;
    justify-content: center;
    background-color: rgb(211, 237, 255);
    text-align: center;
  }
  .img{
      margin-bottom: 10px;
  }
  input{
    margin:0;
  }
  input[type=text]{
    width: 75%;
    height: 70px;;
    border:none;
    font-size:1em;
    padding-left: 5px;
    /* font-style: oblique; */
    border-top-left-radius: 5px;
    border-bottom-left-radius: 5px;
    display:inline;
    outline:none;
    box-sizing: border-box;
    color:black;
    border: 2px solid rgb(248, 226, 136);
  }
  input[type=tel]{
    width: 75%;
    height: 70px;;
    border:none;
    font-size:1em;
    padding-left: 5px;
    /* font-style: oblique; */
    border-top-left-radius: 5px;
    border-bottom-left-radius: 5px;
    display:inline;
    outline:none;
    box-sizing: border-box;
    color:black;
  }
  input[type=submit]{
      height: 70px;;
      border:none;
      background-color: rgb(248, 226, 136);
      border: 1px solid rgb(248, 226, 136);
      border-top-right-radius: 5px;
      border-bottom-right-radius: 5px;
      /* font-size:1em; */
      color:black;
      outline:none;
      display:inline;
      margin-left: -10px;
      box-sizing: border-box;
  }
  /* input[type=button]:hover{ 
    background-color: lightgray;
  }*/
  .couponbox{
      margin-top: 10px;
      width: 54%;
      height: 6px;
      border: 0;
      font-size:1em;
      border-top-left-radius: 5px;
      border-bottom-left-radius: 5px;
      background-color: #ffffff;
      border: 2px solid rgb(248, 226, 136);
      padding: 30px;
      margin: 0 auto;
      float: left;
      line-height: 10px;
    }
    .couponbutton{
      height: 70px;
      border: 1px solid rgb(248, 226, 136);
      background-color: rgb(248, 226, 136);
      color: black;
      border-top-right-radius: 5px;
      border-bottom-right-radius: 5px;
      padding: 5px;
      float: left;
      margin-bottom: 10px;
    }

    .couponname{
      margin-bottom: 10px;
    }

  </style>
</head>
<body>
  <script>
    var div, text, btn

    function cp(id, name, start, end, discount){
      div = document.createElement('div');
      div.classList.add('couponbox');
      text = document.createTextNode(name + " " + discount + start + " ~ " + end);
      div.append(text);
      document.body.append(div);

      btn = document.createElement('input');
      btn.setAttribute("type", "submit");
      btn.setAttribute("value", "쿠폰 삭제");
      btn.classList.add('couponbutton');
      document.body.append(btn);

      btn.setAttribute('onclick', "location.replace('cupon_delete.php?cupon_id=" + id + "');");
    }

  </script>
  <?php
    session_start();
    include "dbconnect.php";
    // $conn = mysqli_connect('localhost', 'root', '', 'project');
    $user_id = $_SESSION['user_id'];
    $store_id = $_SESSION['store_id'];
    // var_dump($_SESSION['store_id']);
    // $sql = "SELECT * FROM cupon WHERE store_id='$store_id'";
    $sql = "SELECT * FROM store WHERE store_id='$store_id'";
    // $sql = "SELECT * FROM cupon LEFT JOIN store ON cupon.store_id=store.store_id WHERE store.store_id='$store_id';";
    $result = mysqli_query($conn, $sql);

    if($store_id === NULL){
      echo "<script>alert('가게등록을 해야합니다.');location.replace('../main/information.php');</script>";
    }else{
      // 가게 정보 상단에 띄우기(DB연동)
        if($row = mysqli_fetch_array($result)){
          $store_name = $row['store_name'];
          $store_img = $row['store_img'];
        }else{
          echo "<script>alert('가게정보가 없습니다.');location.replace('../main/information.php');</script>";
        }
  
        $sql = "SELECT * FROM cupon LEFT JOIN store ON cupon.store_id=store.store_id WHERE store.store_id='$store_id';";
        $result = mysqli_query($conn, $sql);
  ?>

  <div class="img">
    <img src="<?=$store_img?>" height="100px" style="vertical-align:middle;">
    <span id="store_name" style="font-size:20px"><strong><?=$store_name?></strong></span>
  </div>

  <div class="check">
    <h3>출석쿠폰</h3>
    <form action="cupon_send.php" method="post">
    <!-- 전화번호 입력 후 버튼 클릭 시 쿠폰 사용자에게 등록(DB입력) -->
      <input type="tel" name="tel" class="text-field" style="border: 2px solid rgb(80, 159, 224);" placeholder="전화번호를 입력하세요">
      <input type="submit" value="출석체크" class="submit-btn" style="background-color: rgb(80, 159, 224); border: 1px solid rgb(80, 159, 224);">
    </form>  
  </div>

  <div class="coupon">
    <h3>쿠폰</h3>
  </div>

  <?php
   // 세션을 통해 가게가 등록되어 있는지 확인한다.
   
      //등록된 쿠폰이 있는 경우
      while($row = mysqli_fetch_array($result)){
        // echo $row['cupon_name'];
        $cupon_id = $row['cupon_id'];
        $cupon_name = $row['name'];
        $cupon_start = $row['start'];
        $cupon_end = $row['end'];
        $cupon_discount = $row['discount'];
        echo("<script>cp('$cupon_id', '$cupon_name', '$cupon_start', '$cupon_end', '$cupon_discount');</script>");
      }
   }
  ?>

  <div class="couponname" id="cupon_list">
    <!-- <input type="text" name="name" value="" placeholder="쿠폰 이름을 적어주세요"> -->
    <button type="button" id="c_regist" name="name">쿠폰 등록</button>
    <button type="button" onclick="location.replace('../main/information.php');">돌아가기</button>

  </div>
  
  <script>
    document.getElementById('c_regist').addEventListener('click', function(){
      location.replace('cupon_regist_form.html');
    });
  </script>
  
</body>
</html>