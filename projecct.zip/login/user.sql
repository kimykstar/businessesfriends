CREATE TABLE user(
    user_id VARCHAR(25) NOT NULL,
    user_name VARCHAR(20) NOT NULL,
    user_phone VARCHAR(20) NOT NULL,
    user_pw VARCHAR(25) NOT NULL,
    user_type INT(4) NOT NULL,
    PRIMARY KEY(user_id)
);

-- 사용자 분류(1: GUEST(일반사용자), 2: READY(가게인증대기사용자), 3: STORE(가게주인사용자))
CREATE TABLE user_type(
    type_id INT(4) NOT NULL,
    type_name VARCHAR(20) NOT NULL,
    PRIMARY KEY(type_id)
);